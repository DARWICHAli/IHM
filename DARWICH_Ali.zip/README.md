# IHM



If you use ubuntu

to run without app or terminal 

do 

Hit alt + F2
type dconf-editor and hit enter.
in dconf-editor go to org > gnome > nautilus > prefrences
click on executable-text-activation
switch off Use default value. 
change the costom value to 'launch'.

by doing that you can now execute any script by double clicking just like .EXE in windows

final step double click on run.sh

