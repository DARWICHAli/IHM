

#on a pas besoin de make chaque fois. c'est juste parce que c'est pas la version final
#make
#make clean
./IHM
